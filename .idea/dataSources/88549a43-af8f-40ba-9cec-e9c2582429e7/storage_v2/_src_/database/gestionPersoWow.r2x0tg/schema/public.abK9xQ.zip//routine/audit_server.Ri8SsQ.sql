create function audit_server() returns trigger
  language plpgsql
as
$$
BEGIN
    --
    -- Ajoute une ligne dans wow_audit_server pour refléter l'opération réalisée
    -- sur wow_server,
    -- utilise la variable spéciale TG_OP pour cette opération.
    --
    IF (TG_OP = 'DELETE') THEN
        INSERT INTO wow_audit_server SELECT uuid_generate_v4(),'D', now(), user, OLD.*;
        RETURN OLD;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO wow_audit_server SELECT uuid_generate_v4(),'U', now(), user, NEW.*;
        RETURN NEW;
    ELSIF (TG_OP = 'INSERT') THEN
        INSERT INTO wow_audit_server SELECT uuid_generate_v4(),'I', now(), user, NEW.*;
        RETURN NEW;
    END IF;
    RETURN NULL; -- le résultat est ignoré car il s'agit d'un trigger AFTER
END;
$$;

alter function audit_server() owner to postgres;

