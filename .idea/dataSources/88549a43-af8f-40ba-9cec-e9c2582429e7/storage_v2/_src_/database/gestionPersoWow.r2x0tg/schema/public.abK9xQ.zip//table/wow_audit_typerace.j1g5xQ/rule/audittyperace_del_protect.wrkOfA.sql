CREATE RULE audittyperace_del_protect AS
    ON DELETE TO public.wow_audit_typerace DO INSTEAD NOTHING;

