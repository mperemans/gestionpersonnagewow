create function sex_personnage() returns trigger
  language plpgsql
as
$$
BEGIN
    --
    -- Ajoute une ligne dans audit_typeprofession pour refléter l'opération réalisée
    -- sur wow_type_profession,
    -- utilise la variable spéciale TG_OP pour cette opération.
    --
	IF (TG_OP = 'UPDATE') THEN
		IF(NEW.sex <> 'F' OR NEW.sex <> 'M') THEN
			RETURN NULL;
		END IF;
        RETURN NEW;
    ELSIF (TG_OP = 'INSERT') THEN
		IF(NEW.sex <> 'F' OR NEW.sex <> 'M') THEN
			RETURN NULL;
		END IF;
        RETURN NEW;
    END IF;
    RETURN NEW; -- le résultat est ignoré car il s'agit d'un trigger AFTER
END;
$$;

alter function sex_personnage() owner to postgres;

