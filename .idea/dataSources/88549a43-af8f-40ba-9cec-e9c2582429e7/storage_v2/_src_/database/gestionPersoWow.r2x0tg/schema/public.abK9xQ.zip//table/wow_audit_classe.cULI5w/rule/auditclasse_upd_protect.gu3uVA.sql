CREATE RULE auditclasse_upd_protect AS
    ON UPDATE TO public.wow_audit_classe DO INSTEAD NOTHING;

