create function func_checktypeprofession_isdelete(idtype uuid) returns boolean
  language sql
as
$$
select isdeleted from wow_type_profession
where uuid = $1
$$;

alter function func_checktypeprofession_isdelete(uuid) owner to postgres;

