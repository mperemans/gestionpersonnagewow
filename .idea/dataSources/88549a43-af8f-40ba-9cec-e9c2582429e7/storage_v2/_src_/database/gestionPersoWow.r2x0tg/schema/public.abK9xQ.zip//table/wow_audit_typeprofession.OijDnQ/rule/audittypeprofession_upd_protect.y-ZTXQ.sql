CREATE RULE audittypeprofession_upd_protect AS
    ON UPDATE TO public.wow_audit_typeprofession DO INSTEAD NOTHING;

