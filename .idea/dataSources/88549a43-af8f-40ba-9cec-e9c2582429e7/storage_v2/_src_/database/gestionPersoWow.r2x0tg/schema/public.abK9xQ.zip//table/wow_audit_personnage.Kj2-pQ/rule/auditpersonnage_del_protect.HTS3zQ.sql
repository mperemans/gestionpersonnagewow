CREATE RULE auditpersonnage_del_protect AS
    ON DELETE TO public.wow_audit_personnage DO INSTEAD NOTHING;

