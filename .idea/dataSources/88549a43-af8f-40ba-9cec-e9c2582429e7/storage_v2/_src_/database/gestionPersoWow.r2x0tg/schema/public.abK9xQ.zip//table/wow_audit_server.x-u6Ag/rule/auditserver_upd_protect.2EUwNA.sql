CREATE RULE auditserver_upd_protect AS
    ON UPDATE TO public.wow_audit_server DO INSTEAD NOTHING;

