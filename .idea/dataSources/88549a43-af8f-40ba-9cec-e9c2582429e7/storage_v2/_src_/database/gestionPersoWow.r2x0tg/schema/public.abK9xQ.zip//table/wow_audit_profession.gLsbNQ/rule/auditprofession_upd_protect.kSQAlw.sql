CREATE RULE auditprofession_upd_protect AS
    ON UPDATE TO public.wow_audit_profession DO INSTEAD NOTHING;

