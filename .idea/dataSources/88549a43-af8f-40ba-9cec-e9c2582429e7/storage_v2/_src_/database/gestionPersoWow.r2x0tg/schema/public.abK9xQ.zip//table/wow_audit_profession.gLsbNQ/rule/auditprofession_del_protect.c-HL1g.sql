CREATE RULE auditprofession_del_protect AS
    ON DELETE TO public.wow_audit_profession DO INSTEAD NOTHING;

