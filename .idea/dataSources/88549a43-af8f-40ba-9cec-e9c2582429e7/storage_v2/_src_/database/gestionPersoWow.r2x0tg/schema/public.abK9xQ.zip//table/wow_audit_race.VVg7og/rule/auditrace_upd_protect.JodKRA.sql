CREATE RULE auditrace_upd_protect AS
    ON UPDATE TO public.wow_audit_race DO INSTEAD NOTHING;

