CREATE RULE audittypepersonnage_del_protect AS
    ON DELETE TO public.wow_audit_typepersonnage DO INSTEAD NOTHING;

