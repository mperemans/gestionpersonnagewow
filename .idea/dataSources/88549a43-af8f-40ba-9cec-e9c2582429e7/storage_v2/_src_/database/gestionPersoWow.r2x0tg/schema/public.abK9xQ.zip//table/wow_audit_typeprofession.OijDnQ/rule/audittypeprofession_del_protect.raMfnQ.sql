CREATE RULE audittypeprofession_del_protect AS
    ON DELETE TO public.wow_audit_typeprofession DO INSTEAD NOTHING;

