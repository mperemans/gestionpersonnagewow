CREATE RULE audittypepersonnage_upd_protect AS
    ON UPDATE TO public.wow_audit_typepersonnage DO INSTEAD NOTHING;

