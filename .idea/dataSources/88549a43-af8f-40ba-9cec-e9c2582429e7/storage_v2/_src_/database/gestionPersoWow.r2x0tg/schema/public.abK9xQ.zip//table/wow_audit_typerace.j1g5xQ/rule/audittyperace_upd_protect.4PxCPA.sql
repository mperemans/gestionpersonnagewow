CREATE RULE audittyperace_upd_protect AS
    ON UPDATE TO public.wow_audit_typerace DO INSTEAD NOTHING;

