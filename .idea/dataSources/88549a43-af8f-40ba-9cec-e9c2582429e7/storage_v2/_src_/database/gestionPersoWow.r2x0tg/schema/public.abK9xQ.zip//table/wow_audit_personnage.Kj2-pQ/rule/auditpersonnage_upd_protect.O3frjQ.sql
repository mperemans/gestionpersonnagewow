CREATE RULE auditpersonnage_upd_protect AS
    ON UPDATE TO public.wow_audit_personnage DO INSTEAD NOTHING;

